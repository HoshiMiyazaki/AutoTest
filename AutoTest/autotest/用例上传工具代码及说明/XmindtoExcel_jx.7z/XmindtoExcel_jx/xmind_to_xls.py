import xlwt
from xmindparser import xmind_to_dict
import json
from Exce_style import ExcelStyle

class XmindToXsl(ExcelStyle):

    def __init__(self, name):
        """调用类时，读取xmind文件，并生成excel表格"""
        super().__init__()
        try:
            self.xm=xmind_to_dict(name)[0]['topic']
        except Exception as e:
            print(f"打开xmind文件失败:{e}")
        self.workbook=xlwt.Workbook(encoding='utf-8')# 创建一个workbook 并设置编码
        self.worksheet=self.workbook.add_sheet(self.xm['title'],cell_overwrite_ok=True) # 创建工作表，并设置可以重写单元格内容

    def save(self,name1):#保存表格
        self.workbook.save(name1 + ".xls")


    @staticmethod
    def xmind_num(value):
        """获取xmind标题个数"""
        try:
            return len(value["topics"])
        except KeyError:
            return 0

    @staticmethod
    def xmind_title(value):
        """获取xmind标题内容"""
        return value["title"]

    def write_excel(self, result='', edition='', author='', tester=''):
        row0=['需求ID','用例目录','用例名称','前置条件','用例步骤','预期结果','版本','用例作者','测试人员']
        style2 = self.template_one(self.worksheet)
        for i in range(len(row0)):
            self.worksheet.write(0, i, row0[i], style2)

        style = self.template_two()
        x = 0  # 写入数据的当前行数
        z = 0  # 用例的编号
        for i in range(self.xmind_num(self.xm)):
            need_modle=self.xm['topics'][i]
            modnum = self.xmind_num(need_modle)
            if modnum !=0:
                for j in range(modnum):
                    test_suit=need_modle['topics'][j]
                    suit_num=self.xmind_num(test_suit)
                    if suit_num !=0:
                        for k in range(suit_num):
                            test_case = test_suit["topics"][k]
                            z += 1
                            caseNum=self.xmind_num(test_case)
                            # print(test_case)
                            if caseNum != 0:
                                for n in range(len(test_case["topics"])):
                                    x += 1
                                    self.heights(self.worksheet, x, size=2)

                                    test_step = test_case["topics"][n]
                                    #step = f"{n + 1}." + self.xmind_title(test_step)  # 用例步骤
                                    step = self.xmind_title(test_step)  # 用例步骤
                                    test_except = test_step["topics"][0]
                                    result = self.xmind_title(test_except)  # 预期结果
                                    self.worksheet.write(x, 4, step, style) 
                                    self.worksheet.write(x, 5, result, style)  
                                    self.worksheet.write(x, 6, edition, style) # 版本名称
                                    self.worksheet.write(x, 7, author, style)  # 用例作者
                                    self.worksheet.write(x, 8, tester, style)  # 测试人员
                                mod = self.xmind_title(need_modle)  # 用例目录
                                case = self.xmind_title(test_suit)  # 用例名称
                                premise = self.xmind_title(test_case)  # 前置条件
                                self.worksheet.write_merge(x - caseNum + 1, x, 0, 0, z,style)  # 写入需求ID
                                self.worksheet.write_merge(x - caseNum + 1, x, 1, 1, mod, style)  # 写入用例目录
                                self.worksheet.write_merge(x - caseNum + 1, x, 2, 2, case, style)  # 写入用例名称
                                self.worksheet.write_merge(x - caseNum + 1, x, 3, 3, premise, style)  # 写入前置条件
                                #self.worksheet.write_merge(x - caseNum + 1, x, 6, 6, edition, style)  # 写入版本名称
                            else:
                                print("测试用例没有操作步骤及预期结果")
                    else:
                         print("没有测试用例")
            else:
                print("没有测试套件")

        self.save(self.xm["title"])  # 保存




if __name__ == "__main__":
    '''此处导图名字、版本、作者、测试者需要修改'''
    names = "巫师1.0.0 修改完成.xmind"    
    xx = XmindToXsl(names)
    edition = "1.0.0"
    author = "蒋星"
    tester = "蒋星"
    xx.write_excel('',edition,author,tester)