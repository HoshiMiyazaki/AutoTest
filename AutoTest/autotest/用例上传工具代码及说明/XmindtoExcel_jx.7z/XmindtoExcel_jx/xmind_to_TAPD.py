import os
import shutil

import xlwt
from xmindparser import xmind_to_dict
import json
from Exce_style import ExcelStyle
import datetime

class XmindToXsl(ExcelStyle):

    def __init__(self, name):
        """调用类时，读取xmind文件，并生成excel表格"""
        super().__init__()
        try:
            self.xm=xmind_to_dict(name)[0]['topic']
        except Exception as e:
            print(f"打开xmind文件失败:{e}")
        # print(json.dumps(self.xm,indent=2,ensure_ascii=False))
        self.file_name=str(datetime.datetime.now()).replace(":", "-")[:10]+".xls"
        self.workbook=xlwt.Workbook(encoding='utf-8')
        self.worksheet=self.workbook.add_sheet(self.xm['title'],cell_overwrite_ok=True) # 创建工作表，并设置可以重写单元格内容

    def save(self):#保存表格
        self.workbook.save(self.file_name)

    @staticmethod
    def xmind_num(value):
        """获取xmind标题个数"""
        try:
            return len(value["topics"])
        except KeyError:
            return 0

    @staticmethod
    def xmind_title(value):
        """获取xmind标题内容"""
        return value["title"]

    def write_excel(self, status='正常', author='', casetype='功能测试', taskid='', level='中'):
        row0=['用例目录','用例名称','需求ID','前置条件','用例步骤','预期结果','用例类型','用例状态','用例等级','创建人']
        style2 = self.template_one(self.worksheet)
        for i in range(len(row0)):
            self.worksheet.write(0, i, row0[i], style2)

        style = self.template_two()

        x = 0  # 写入数据的当前行数
        z = 0  # 用例的编号

        for i in range(self.xmind_num(self.xm)):
            test_modle=self.xm['topics'][i]
            modnum = self.xmind_num(test_modle)
            if modnum !=0:
                for j in range(modnum):
                    test_case=test_modle['topics'][j]
                    suit_num=self.xmind_num(test_case)
                    if suit_num !=0:
                        for k in range(suit_num):
                            test_premise = test_case["topics"][k]
                            z+=1
                            c1=self.xmind_num(test_premise)
                            # print(test_case)
                            if c1 != 0:
                                for n in range(len(test_premise["topics"])):
                                    x += 1
                                    test_step = test_premise["topics"][n]
                                    test_except = test_step["topics"][0]
                                    # print(test_except)
                                    self.heights(self.worksheet, x, size=2)
                                    step = self.xmind_title(test_step)  # 执行步骤
                                    exce = self.xmind_title(test_except)  # 预期结果
                                    self.worksheet.write(x, 4, step,style)  # 用例步骤
                                    self.worksheet.write(x, 5, exce,style)    # 预期结果
                                    self.worksheet.write(x, 7, status, style)  # 用例状态
                                    self.worksheet.write(x, 9, author, style)  # 用例作者
                                mod = self.xmind_title(test_modle)  # 测试用例名称
                                premise = self.xmind_title(test_premise)  # 前置条件
                                case = self.xmind_title(test_case)  # 测试用例名称
                                self.worksheet.write_merge(x - c1 + 1, x, 2, 2, taskid, style) # 需求ID
                                self.worksheet.write_merge(x - c1 + 1, x, 0, 0, mod, style)     # 测试用例名称
                                self.worksheet.write_merge(x - c1 + 1, x, 1, 1, case, style)    # 测试用例名称
                                self.worksheet.write_merge(x - c1 + 1, x, 3, 3, premise, style)    # 前置条件
                                self.worksheet.write_merge(x - c1 + 1, x, 6, 6, casetype, style)  # 用例类型
                                self.worksheet.write_merge(x - c1 + 1, x, 8, 8, level, style) # 用例等级
                            else:
                                print("测试用例没有操作步骤及预期结果")
                    else:
                         print("没有测试用例")
            else:
                print("没有测试套件")

        self.save()  # 保存
        aa=os.getcwd()
        file_path=os.path.join(aa,self.file_name)
        #target_path=r"C:\Users\Administrator\Desktop"
        target_path=r"C:\Users\admin\Desktop"                ###桌面地址需要自行设置###
        shutil.move(file_path, target_path)

if __name__ == "__main__":
    names = "APPtest.xmind"
    xx = XmindToXsl(names)
    xx.write_excel()