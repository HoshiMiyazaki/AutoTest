import time
from selenium import webdriver
from selenium.webdriver.common.by import By
import xlrd
import datetime

def Catch(self):
    #��xls�ĵ�
    file_name=str(datetime.datetime.now()).replace(":", "-")[:10]+".xls"
    #open("file_name","w",encoding = 'utf-8')
    workbook=xlrd.open_workbook('file_name')
    worksheet = workbook.sheet_by_index(0)
   
    driver = webdriver.Chrome()
    driver.get('https://www.tapd.cn/55892030/prong/stories/stories_list?category_id=1155892030001000978')
    #driver.find_element(By.ID, 'username').send_keys('xing.jiang@xiaoxitech.com')
    driver.find_element(By.ID, 'username').send_keys('18883286243')
    driver.find_element(By.ID, 'password_input').send_keys('Jx123456')
    time.sleep(2)
    driver.find_element(By.ID, 'tcloud_login_button').click()
    time.sleep(2)
    driver.maximize_window()
  
    
    #д������id
    for row in worksheet.get_rows():
    self.task = row[1].value

    driver.find_element(By.LINK_TEXT, self.task) 

    #�������
    workbook.save(file_name)


    time.sleep(60)
 

